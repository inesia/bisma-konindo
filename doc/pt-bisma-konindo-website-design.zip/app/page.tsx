import { Certifications } from '@/components/site/certifications'
import { Company } from '@/components/site/company'
import { Field } from '@/components/site/field'
import { FinalCta } from '@/components/site/final-cta'
import { Footer } from '@/components/site/footer'
import { Header } from '@/components/site/header'
import { Hero } from '@/components/site/hero'
import { MobileCta } from '@/components/site/mobile-cta'
import { Operations } from '@/components/site/operations'
import { Positioning } from '@/components/site/positioning'
import { Protect } from '@/components/site/protect'
import { RevealObserver } from '@/components/site/reveal-observer'
import { Services } from '@/components/site/services'
import { Standard } from '@/components/site/standard'
import { TrustStrip } from '@/components/site/trust-strip'
import { WhyBisma } from '@/components/site/why-bisma'

export default function Page() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <TrustStrip />
        <Positioning />
        <Services />
        <Standard />
        <Operations />
        <Protect />
        <WhyBisma />
        <Field />
        <Certifications />
        <Company />
        <FinalCta />
      </main>
      <Footer />
      <MobileCta />
      <RevealObserver />
    </>
  )
}
