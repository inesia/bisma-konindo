import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter_Tight, IBM_Plex_Mono } from 'next/font/google'
import './globals.css'

const interTight = Inter_Tight({
  subsets: ['latin'],
  variable: '--font-inter-tight',
  display: 'swap',
})

const plexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '500'],
  variable: '--font-plex-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'PT. Bisma Konindo — Security Personnel & Security Operations',
  description:
    'PT Bisma Konindo provides professional security personnel supported by structured operational systems, training, supervision, and coordination for companies, buildings, and industrial facilities in Indonesia.',
  generator: 'v0.app',
  openGraph: {
    title: 'PT. Bisma Konindo — Security That Protects Business',
    description:
      'Integrated security personnel, operational control, and disciplined field execution.',
    images: ['/images/hero.png'],
  },
}

export const viewport: Viewport = {
  themeColor: '#0D1014',
  colorScheme: 'light',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${interTight.variable} ${plexMono.variable}`}>
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
