export const WHATSAPP_DISPLAY = '0813 9847 8490'
const WHATSAPP_NUMBER = '6281398478490'

export function whatsappLink(message?: string) {
  const base = `https://wa.me/${WHATSAPP_NUMBER}`
  return message ? `${base}?text=${encodeURIComponent(message)}` : base
}

export const ASSESSMENT_LINK = whatsappLink(
  'Hello PT Bisma Konindo, I would like to request a security assessment for our site.\n\nCompany:\nSite location:\nSite type:\nEstimated posts / personnel:',
)

export const NAV = [
  { label: 'About', href: '#company' },
  { label: 'Services', href: '#services' },
  { label: 'The Bisma Standard', href: '#standard' },
  { label: 'Operations', href: '#operations' },
  { label: 'Certifications', href: '#certifications' },
]

export const SERVICES = [
  {
    name: 'Physical Security',
    description:
      'Protection of personnel, buildings, facilities, vehicles, and company assets.',
    scope: ['Personnel', 'Buildings', 'Assets'],
  },
  {
    name: 'Preventive Security',
    description:
      'Patrols, access control, observation, inspection, and early prevention of potential disturbances.',
    scope: ['Patrol', 'Observation', 'Inspection'],
  },
  {
    name: 'Security Operations',
    description:
      'Structured post management, shifts, supervision, reporting, and coordination.',
    scope: ['Posts', 'Shifts', 'Reporting'],
  },
  {
    name: 'Access & Area Control',
    description:
      'Monitoring personnel, visitors, vehicles, and restricted areas.',
    scope: ['Visitors', 'Vehicles', 'Restricted'],
  },
  {
    name: 'Emergency Response',
    description:
      'Handling incidents according to established security procedures and coordination requirements.',
    scope: ['Incident', 'Procedure', 'Coordination'],
  },
]

export const TRAINING_SUBJECTS = [
  'Physical training',
  'Marching discipline',
  'Security baton & handcuff exercises',
  'Early bomb detection awareness',
  'Crowd / disturbance response',
  'Fire fighting',
  'First aid',
  'VIP escort',
  'Service excellence',
  'Criminal / civil law knowledge',
  'Incident reporting',
  'Patrol procedures',
  'Vehicle & personnel inspection',
  'Traffic control',
  'Crime prevention',
  'First response at incident locations',
  'Negotiation',
  'Communication',
  'Self defense',
  'Interpersonal skills',
]

export type Certification = {
  title: string
  category: string
  description: string
  authority?: string
}

export const CERTIFICATION_GROUPS: {
  group: string
  code: string
  items: Certification[]
}[] = [
  {
    group: 'Corporate Legal',
    code: 'A',
    items: [
      {
        title: 'Akta Pendirian Perseroan',
        category: 'Corporate Legal',
        description: 'Deed of establishment of the limited liability company.',
        authority: 'Notary',
      },
      {
        title: 'Akta Perubahan Perseroan',
        category: 'Corporate Legal',
        description: 'Deed of amendment to the company’s articles of association.',
        authority: 'Notary',
      },
      {
        title: 'Pengesahan Menteri AHU',
        category: 'Corporate Legal',
        description: 'Ministerial ratification of the company’s legal entity status.',
        authority: 'Kementerian Hukum — Ditjen AHU',
      },
      {
        title: 'NPWP',
        category: 'Corporate Legal',
        description: 'Corporate taxpayer identification number.',
        authority: 'Direktorat Jenderal Pajak',
      },
      {
        title: 'NIB',
        category: 'Corporate Legal',
        description: 'Business identification number for licensed operations.',
        authority: 'OSS — Online Single Submission',
      },
    ],
  },
  {
    group: 'Security Operating Licenses',
    code: 'B',
    items: [
      {
        title: 'ABUJAPI',
        category: 'Security Operating License',
        description:
          'Asosiasi Badan Usaha Jasa Pengamanan Indonesia — Indonesian security services business association.',
        authority: 'ABUJAPI',
      },
      {
        title: 'SIO Pelatihan Keamanan',
        category: 'Security Operating License',
        description: 'Operating license for the provision of security training.',
        authority: 'Polri',
      },
      {
        title: 'SIO Penyedia Tenaga Keamanan',
        category: 'Security Operating License',
        description: 'Operating license for the provision of security personnel.',
        authority: 'Polri',
      },
      {
        title: 'W.L.K. Disnaker',
        category: 'Security Operating License',
        description: 'Mandatory company employment report (Wajib Lapor Ketenagakerjaan).',
        authority: 'Dinas Tenaga Kerja',
      },
    ],
  },
  {
    group: 'Employment & Welfare',
    code: 'C',
    items: [
      {
        title: 'BPJS Kesehatan',
        category: 'Employment & Welfare',
        description: 'National health insurance registration for personnel.',
        authority: 'BPJS Kesehatan',
      },
      {
        title: 'BPJS Ketenagakerjaan',
        category: 'Employment & Welfare',
        description: 'Employment social security registration for personnel.',
        authority: 'BPJS Ketenagakerjaan',
      },
    ],
  },
  {
    group: 'Leadership & Professional Qualifications',
    code: 'D',
    items: [
      {
        title: 'Gada Utama',
        category: 'Professional Qualification',
        description: 'Highest tier of the Indonesian security officer qualification (managerial level).',
      },
      {
        title: 'Auditor SMP',
        category: 'Professional Qualification',
        description: 'Security Management System (Sistem Manajemen Pengamanan) auditor.',
      },
      {
        title: 'Sespim Polri',
        category: 'Professional Qualification',
        description: 'Police leadership staff school qualification.',
      },
      {
        title: 'K3 Umum / BNSP',
        category: 'Professional Qualification',
        description: 'General occupational health & safety certification.',
        authority: 'BNSP',
      },
      {
        title: 'Auditor Internal SMK3',
        category: 'Professional Qualification',
        description: 'Internal auditor for occupational health & safety management systems.',
      },
      {
        title: 'ToT / BNSP',
        category: 'Professional Qualification',
        description: 'Training of Trainers certification.',
        authority: 'BNSP',
      },
      {
        title: 'Investigasi Polri',
        category: 'Professional Qualification',
        description: 'Investigation qualification.',
      },
      {
        title: 'Manajemen Tanggap Darurat',
        category: 'Professional Qualification',
        description: 'Emergency response management.',
      },
    ],
  },
]
