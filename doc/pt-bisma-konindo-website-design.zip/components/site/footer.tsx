import { NAV, WHATSAPP_DISPLAY, whatsappLink } from '@/lib/site'
import { Wordmark } from './primitives'

const CAPABILITIES = ['Security Personnel', 'Security Operations', 'Training', 'Supervision']

export function Footer() {
  return (
    <footer className="border-t border-paper/10 bg-ink-2 pt-16 pb-28 text-paper md:pb-10">
      <div className="shell">
        <div className="grid grid-cols-12 gap-x-6 gap-y-10">
          <div className="col-span-12 md:col-span-4">
            <Wordmark />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-paper/50">
              Security personnel and security operations for companies, buildings,
              and industrial facilities in Indonesia.
            </p>
          </div>
          <div className="col-span-6 md:col-span-3">
            <p className="meta text-paper/40">Capabilities</p>
            <ul className="mt-4 space-y-2 text-sm text-paper/75">
              {CAPABILITIES.map((c) => (
                <li key={c}>{c}</li>
              ))}
            </ul>
          </div>
          <div className="col-span-6 md:col-span-2">
            <p className="meta text-paper/40">Index</p>
            <ul className="mt-4 space-y-2 text-sm">
              {NAV.map((n) => (
                <li key={n.href}>
                  <a href={n.href} className="text-paper/75 hover:text-paper">
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div className="col-span-12 md:col-span-3">
            <p className="meta text-paper/40">Contact</p>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <a
                  href={whatsappLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="tabular-nums text-paper/75 hover:text-paper"
                >
                  {WHATSAPP_DISPLAY}
                </a>
              </li>
              <li>
                <a
                  href="https://bismakonindo.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-paper/75 hover:text-paper"
                >
                  bismakonindo.com
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 flex flex-col justify-between gap-3 border-t border-paper/10 pt-6 md:flex-row">
          <p className="meta text-paper/40">
            © {new Date().getFullYear()} PT. Bisma Konindo. All rights reserved.
          </p>
          <p className="meta text-paper/40">Security Personnel Provider · Indonesia</p>
        </div>
      </div>
    </footer>
  )
}
