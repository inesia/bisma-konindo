import Image from 'next/image'
import { cn } from '@/lib/utils'
import { SectionIndex, delay } from './primitives'

type Shot = {
  src: string
  alt: string
  label: string
  caption: string
  aspect: string
  mono?: boolean
  className?: string
  sizes: string
}

const SHOTS: Record<string, Shot> = {
  patrol: {
    src: '/images/patrol.png',
    alt: 'Two security officers walking a perimeter patrol route along an industrial facility fence at dawn.',
    label: 'Patrol',
    caption: 'Perimeter route, early shift',
    aspect: 'aspect-[16/10]',
    sizes: '(min-width: 768px) 58vw, 100vw',
  },
  gate: {
    src: '/images/gate-control.png',
    alt: 'A security officer inspecting an arriving truck at an industrial site gate.',
    label: 'Gate Control',
    caption: 'Vehicle inspection at entry',
    aspect: 'aspect-[4/5]',
    sizes: '(min-width: 768px) 34vw, 100vw',
  },
  briefing: {
    src: '/images/briefing.png',
    alt: 'Security personnel standing in formation during a morning appel while the shift leader briefs them.',
    label: 'Security Briefing',
    caption: 'Appel before shift handover',
    aspect: 'aspect-[21/9]',
    mono: true,
    sizes: '100vw',
  },
  access: {
    src: '/images/access-control.png',
    alt: 'A security officer checking a visitor identification card at a lobby reception desk.',
    label: 'Access Control',
    caption: 'Visitor verification, lobby',
    aspect: 'aspect-square',
    sizes: '(min-width: 768px) 30vw, 100vw',
  },
  supervision: {
    src: '/images/supervision.png',
    alt: 'A shift supervisor reviewing the patrol logbook with a security officer at a night post.',
    label: 'Site Supervision',
    caption: 'Night logbook review',
    aspect: 'aspect-[3/2]',
    sizes: '(min-width: 768px) 50vw, 100vw',
  },
}

function Figure({ shot, index, className }: { shot: Shot; index: number; className?: string }) {
  return (
    <figure className={cn('group', className)}>
      <div
        data-reveal="image"
        style={delay(index * 80)}
        className={cn('relative overflow-hidden bg-ink', shot.aspect)}
      >
        <Image
          src={shot.src}
          alt={shot.alt}
          fill
          sizes={shot.sizes}
          className={cn(
            'object-cover transition-[filter] duration-700',
            shot.mono ? 'grayscale' : 'saturate-[0.65] group-hover:saturate-100',
          )}
        />
      </div>
      <figcaption className="mt-3 flex items-baseline justify-between gap-4 border-t border-ink/15 pt-3">
        <span className="flex items-baseline gap-3">
          <span className="meta text-signal">{String(index + 1).padStart(2, '0')}</span>
          <span className="text-[13px] font-semibold uppercase tracking-[0.06em]">{shot.label}</span>
        </span>
        <span className="meta text-right text-steel">{shot.caption}</span>
      </figcaption>
    </figure>
  )
}

export function Field() {
  return (
    <section aria-labelledby="field-title" className="overflow-hidden bg-white py-24 md:py-36">
      <div className="shell">
        <div className="grid grid-cols-12 gap-x-6 gap-y-10">
          <div className="col-span-12 lg:col-span-3">
            <SectionIndex index="07" label="Security in Action" />
          </div>
          <div className="col-span-12 md:col-span-8 lg:col-span-6">
            <h2
              id="field-title"
              data-reveal
              className="display text-[44px] md:text-7xl lg:text-[88px]"
            >
              Discipline
              <br />
              is visible
              <br />
              in the field.
            </h2>
          </div>
          <p className="meta col-span-12 self-end text-steel md:col-span-4 lg:col-span-3">
            Field documentation — patrol, gate, appel, access, and supervision across
            client sites.
          </p>
        </div>

        <div className="mt-20 grid grid-cols-12 gap-x-6 gap-y-14 md:mt-28">
          <Figure shot={SHOTS.patrol} index={0} className="col-span-12 md:col-span-7 md:-ml-14 lg:-ml-24" />
          <Figure shot={SHOTS.gate} index={1} className="col-span-12 md:col-span-4 md:col-start-9 md:mt-40" />

          <Figure shot={SHOTS.briefing} index={2} className="col-span-12 md:-mr-10 lg:-mr-14" />

          <Figure shot={SHOTS.access} index={3} className="col-span-8 md:col-span-4 md:col-start-2" />
          <div className="col-span-12 md:col-span-6 md:col-start-7 md:mt-24">
            <blockquote data-reveal className="border-l border-signal pl-6">
              <p className="text-2xl leading-[1.2] tracking-[-0.02em] md:text-[30px]">
                Every post has a procedure. Every shift has a leader. Every handover is
                recorded.
              </p>
              <footer className="meta mt-5 text-steel">Operating principle</footer>
            </blockquote>
            <Figure shot={SHOTS.supervision} index={4} className="mt-14" />
          </div>
        </div>
      </div>
    </section>
  )
}
