import { SectionIndex, delay } from './primitives'

const STATEMENTS = [
  {
    title: 'Trained Personnel',
    body: 'Personnel are trained through structured education and ongoing development.',
  },
  {
    title: 'Structured Operations',
    body: 'Security execution is supported by SOP, shift structures, post coordination, and reporting.',
  },
  {
    title: 'Experienced Leadership',
    body: 'Supported by experienced operational personnel and security-related expertise.',
  },
  {
    title: 'Strong Coordination',
    body: 'Designed to coordinate with relevant security and environmental stakeholders.',
  },
]

const EXPERTISE = ['Security', 'Operations', 'Telecommunications', 'Change Management']

export function WhyBisma() {
  return (
    <section aria-labelledby="why-title" className="bg-paper py-24 md:py-36">
      <div className="shell grid grid-cols-12 gap-x-6 gap-y-14">
        <div className="col-span-12 lg:col-span-5">
          <div className="lg:sticky lg:top-28">
            <SectionIndex index="06" label="Why Bisma" />
            <h2
              id="why-title"
              data-reveal
              className="display mt-10 text-[44px] md:text-7xl lg:text-[80px]"
            >
              Built for
              <br />
              real-world
              <br />
              operations.
            </h2>
          </div>
        </div>

        <div className="col-span-12 lg:col-span-7">
          <ol className="grid grid-cols-1 sm:grid-cols-2 sm:gap-x-10">
            {STATEMENTS.map((s, i) => (
              <li
                key={s.title}
                data-reveal
                style={delay(i * 100)}
                className="border-t border-ink pt-6 pb-12"
              >
                <span className="meta text-signal">{String(i + 1).padStart(2, '0')}</span>
                <h3 className="mt-6 text-[26px] font-medium leading-[1.05] tracking-[-0.025em] md:text-3xl">
                  {s.title}
                </h3>
                <p className="mt-4 max-w-sm text-[15px] leading-relaxed text-ink/70">
                  {s.body}
                </p>
              </li>
            ))}
          </ol>

          <div data-reveal className="mt-6 bg-white p-8 md:p-12">
            <p className="meta text-steel">Background of the team</p>
            <p className="mt-6 text-2xl leading-[1.2] tracking-[-0.02em] md:text-[32px]">
              Our people have experience serving{' '}
              <span className="text-signal">multinational companies</span> and
              special security services, supported by consultants across four
              disciplines.
            </p>
            <ul className="mt-10 grid grid-cols-2 border-t border-ink/15 md:grid-cols-4">
              {EXPERTISE.map((e, i) => (
                <li
                  key={e}
                  className="border-b border-ink/15 py-4 pr-3 md:border-b-0 md:[&:not(:first-child)]:border-l md:[&:not(:first-child)]:pl-4"
                >
                  <span className="meta text-steel">C.0{i + 1}</span>
                  <p className="mt-1 text-[15px] font-medium">{e}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  )
}
